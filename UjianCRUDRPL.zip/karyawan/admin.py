from django.contrib import admin
from .models import Karyawan

admin.site.register(Karyawan)
