from django.db import models

class Karyawan(models.Model):
    nama = models.CharField(max_length=100)
    jabatan = models.CharField(max_length=100)
    gaji = models.DecimalField(max_digits=10, decimal_places=2)
    tanggal_bergabung = models.DateField()

    def __str__(self):
        return self.nama
