from django import forms
from .models import Karyawan

class KaryawanForm(forms.ModelForm):
    class Meta:
        model = Karyawan
        fields = ['nama', 'jabatan', 'gaji', 'tanggal_bergabung']

        widgets = {
            'tanggal_bergabung': forms.DateInput(attrs={'type': 'date'}),
            'gaji': forms.NumberInput(attrs={'step': '10000'}),
        }
