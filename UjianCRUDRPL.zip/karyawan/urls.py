from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('tambah/', views.tambah_karyawan, name='tambah_karyawan'),
    path('edit/<int:pk>/', views.edit_karyawan, name='edit_karyawan'),
    path('hapus/<int:pk>/', views.hapus_karyawan, name='hapus_karyawan'),
]
