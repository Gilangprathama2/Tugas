from django.shortcuts import render, redirect, get_object_or_404
from .models import Karyawan
from .forms import KaryawanForm

# READ: Menampilkan daftar karyawan
def index(request):
    karyawans = Karyawan.objects.all()
    return render(request, 'karyawan/index.html', {'karyawans': karyawans})

# CREATE: Menambah data karyawan
def tambah_karyawan(request):
    if request.method == 'POST':
        form = KaryawanForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = KaryawanForm()
    return render(request, 'karyawan/tambah.html', {'form': form})

# UPDATE: Edit data karyawan
def edit_karyawan(request, pk):
    karyawan = get_object_or_404(Karyawan, pk=pk)
    if request.method == 'POST':
        form = KaryawanForm(request.POST, instance=karyawan)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = KaryawanForm(instance=karyawan)
    return render(request, 'karyawan/edit.html', {'form': form})

# DELETE: Hapus data karyawan
def hapus_karyawan(request, pk):
    karyawan = get_object_or_404(Karyawan, pk=pk)
    if request.method == 'POST':
        karyawan.delete()
        return redirect('index')
    return render(request, 'karyawan/hapus.html', {'karyawan': karyawan})
